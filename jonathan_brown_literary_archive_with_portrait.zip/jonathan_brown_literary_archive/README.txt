JONATHAN BROWN — LITERARY ARCHIVE

Included:
- index.html: a responsive, English-language literary archive with SEO metadata, canonical URL, and Schema.org structured data.

Before publishing:
1. Confirm the final GitHub Pages URL. The canonical URL currently assumes:
   https://jonathanbrownbooks.github.io/literary-archive/
2. If the repository or path differs, update the canonical URL in index.html.
3. Review all biographical and bibliographic claims before publishing.
4. Publish through GitHub Pages, then inspect the live page and submit its URL in Google Search Console.
5. Indexing and ranking are controlled by Google and are not guaranteed.

This project is a static website and does not require a paid backend.

Image asset: assets/jonathan-brown.jpg. Upload the assets folder along with index.html so the portrait displays correctly.
